#! /usr/bin/python3
# -*- coding: utf-8 -*-
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#
# Create a png image from a 2D vtk
#
# ./vtk2img.py  [FILE]
#
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


myred  = np.array( [255,135,135] )/256.0
myblue = np.array( [128,179,255] )/256.0
mycmap = ListedColormap(['k','w',myred,myblue])





ifiles=sys.argv[1:]




for ifile in ifiles:
  
  
  vtk = np.loadtxt( ifile , dtype=float, skiprows=10 )
  
  ny = len(vtk)    / 100.0
  nx = len(vtk[0]) / 100.0
  
  
  plt.figure(figsize=(nx,ny))
  plt.subplots_adjust(left=0, bottom=0, right=1, top=1)
  plt.imshow(vtk,cmap=mycmap)
  # plt.show()
  plt.savefig(ifile+".png")
  plt.close()



