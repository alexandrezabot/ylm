#! /usr/bin/python3
# -*- coding: utf-8 -*-

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
import numpy as np
import matplotlib.pylab as plt



angs=[ "00", "20", "40" ]



for a in angs:
  D = np.loadtxt( "ang%s/outimg/d.dat"%a, dtype=float ).transpose()
  plt.plot( D[1], D[5], "o-", label=a )


plt.gca().invert_xaxis()
plt.margins(0.1)
plt.xlabel(u"Diameter (px)")
plt.ylabel(u"Saturation")
plt.legend(loc="upper left")
plt.grid()
plt.subplots_adjust(left=0.1, bottom=0.1, right=0.96, top=0.97)
plt.show()
