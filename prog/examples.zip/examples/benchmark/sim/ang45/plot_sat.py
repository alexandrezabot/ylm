#! /usr/bin/python3
# -*- coding: utf-8 -*-

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
import sys
import numpy as np
import matplotlib.pylab as plt



ifiles=sys.argv[1:]



for ifile in ifiles:
  D = np.loadtxt( ifile , dtype=float ).transpose()
  plt.plot( D[1], D[4], "o-", label=ifile )


plt.gca().invert_xaxis()
plt.margins(0.1)
plt.xlabel(u"Diameter (px)")
plt.ylabel(u"Saturation")
plt.legend(loc="upper left")
plt.grid()
plt.subplots_adjust(left=0.1, bottom=0.1, right=0.96, top=0.97)
plt.show()
